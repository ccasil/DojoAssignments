-- INSERT INTO friends (first_name, last_name, occupation, created_at, updated_at)
-- VALUES ("Jay", "Patel", "Instructor", NOW(), NOW());
-- INSERT INTO friends (first_name, last_name, occupation, created_at, updated_at)
-- VALUES ("Jimmy", "Jun", "Instructor", NOW(), NOW());

-- INSERT INTO friends (first_name, last_name, occupation, created_at, updated_at)
-- VALUES ("Andrew", "Lee", "Instructor", NOW(), NOW());

SELECT * FROM friends;