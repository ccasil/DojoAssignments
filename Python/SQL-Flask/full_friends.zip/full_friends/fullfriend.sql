INSERT INTO friends (name, age, friend_since)
VALUES ("Kyle Casil", "203", NOW());
INSERT INTO friends (name, age, friend_since)
VALUES ("Wiseman Z", "239", NOW());

INSERT INTO friends (name, age, friend_since)
VALUES ("Bo Lee", "44", NOW());

SELECT * FROM friends;