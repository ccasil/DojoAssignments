var math = require('./mathlib')();     //notice the extra invocation parentheses!
console.log(math);
math.add(2,3);
math.multiply(3,5)
math.square(5)
math.random(1,35)