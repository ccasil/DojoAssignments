//
//  AddWordViewController.swift
//  madlibs
//
//  Created by Cesar Casil on 3/13/18.
//  Copyright © 2018 Cesar Casil. All rights reserved.
//

import UIKit

class AddWordViewController: UIViewController {
    
    @IBOutlet weak var adjectiveTextField: UITextField!
    @IBOutlet weak var verb1TextField: UITextField!
    @IBOutlet weak var verb2TextField: UITextField!
    @IBOutlet weak var nounTextField: UITextField!
    weak var delegate: AddWordViewControllerDelegate?
    
    @IBAction func submitButtonPressed(_ sender: UIButton) {
//        dismiss(animated: true, completion: nil)
        if let adjectiveTextField.text = adjective {
            let adjectived = adjectiveTextField.text
        }
        if let verb1TextField.text =  verb1 {
            let verb1d = verb1TextField.text
        }
        if let verb2TextField.text =  verb2 {
            let verb2d =  verb2TextField.text
        }
        if let nounTextField.text =  noun {
            let nound = nounTextField.text
        }
        changeWords(adjective, verb1, verb2, noun)
        performSegue(withIdentifier: "unwindToMadLib", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination as! MadLibViewController
            destination.adjective = adjective
        if let verbs1 = verb1TextField.text {
            destination.verb1 = verbs1
        }
        if let verbs2 = verb2TextField.text {
            destination.verb2 =  verbs2
        }
        if let nouns = nounTextField.text {
            destination.noun = nouns
        }
    }

}
