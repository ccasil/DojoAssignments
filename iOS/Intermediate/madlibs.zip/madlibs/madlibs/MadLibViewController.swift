//
//  MadLibViewController.swift
//  madlibs
//
//  Created by Cesar Casil on 3/13/18.
//  Copyright © 2018 Cesar Casil. All rights reserved.
//

import UIKit

class MadLibViewController: UIViewController, AddWordViewControllerDelegate {
    
    @IBOutlet weak var madLibLabel: UILabel!
    var adjective: String?
    var verb1: String?
    var verb2: String?
    var noun:String?
    
    
    func changeWords(_ adjective: String, _ verb1: String, _ verb2: String, _ noun: String) {
        var madlib: String = "We are having a perfectly \(adjective) time now. Later we will \(verb1) and \(verb2) in the \(noun)."
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        madLibLabel.text = madlib
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func unwindToMadLib (segue: UIStoryboardSegue) { }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination as! AddWordViewController
        destination.delegate = self
    }
    
    @IBAction func composeButtonPressed(_ sender: UIBarButtonItem) {
        performSegue(withIdentifier: "AddWordViewController", sender: sender)
    }
}
