//
//  AddWordViewControllerDelegate.swift
//  madlibs
//
//  Created by Cesar Casil on 3/14/18.
//  Copyright © 2018 Cesar Casil. All rights reserved.
//

import UIKit

protocol AddWordViewControllerDelegate {
    func changeWords(_ adjective: String, _ verb1: String,_ verb2: String,_ noun: String)
}
